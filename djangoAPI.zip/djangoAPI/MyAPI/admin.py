from django.contrib import admin
from . models import PredictModel

# Register your models here.
admin.site.register(PredictModel)