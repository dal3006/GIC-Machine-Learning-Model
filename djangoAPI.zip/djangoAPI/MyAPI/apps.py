from django.apps import AppConfig


class MyapiConfig(AppConfig):
    name = 'MyAPI'
